
<?php  
include 'head.php';  
include 'db_collect.php';  
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['update'])){ 
    $product_code=$_POST['icode'];  
    $product_quentity=$_POST['product_quentity'];
    $product_price=$_POST['product_price'];
    $product_tprice=$_POST['product_tprice'];
    $product_info=$_POST['product_info'];  
   

    try{/*

    echo "<br>updated<br>";*/  

        $sql = "UPDATE product SET quentity='$product_quentity', price='$product_price',
         tprice='$product_tprice', info='$product_info' WHERE icode ='$product_code'"; 
        // echo $sql;

// Pass the query variable to mysqli_query()
            $update_query = mysqli_query($conn, $sql);

// Optional: check for errors
            if ($update_query) {
                    echo "Record updated successfully";
                } else {
                    echo "Error updating record: " . mysqli_error($conn);
                }
} 
catch(Exception $e){
    echo "Error  !!!!";
}
if($update_query){
    echo "<br>product update";  
    //header('location:sell.php'); 
    //exit();
}
    else{
        $display_message= "some thing error in uploding";
    }
 }   


?> 
<html>

<style>
    .form-container {
        margin: 20px; /* Adds space around the form */
    }

    .form-group {
        margin-bottom: 15px; /* Adds space between form groups */
    }

    input, textarea, select {
        padding: 10px; /* Adds space inside form controls */
        margin-right: 10px; /* Adds space to the right of form controls */
    }
  .form
          {
              display: flex;
              flex-direction: column;
              height: 490px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 70px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          .body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
  </style> 
<body class="body"> 

<div class="form-container"> 
        <!-- message --> 
         <?php  
         if(isset($display_message)){
            echo "<div class='display_message'> <span>$display_message </span> 
            <i class='fas fa-times' onclick='this.parentElement.style.display=`none`';></i>
             </div";
         }
         ?> 
         
<form class="form" action="" method="post" enctype="multipart/form-data"> 
    <center> 
        <div class="form-group"> <br>
    code : <input type="text" name="icode"><br></div>
        <div class="form-group">
        product Quentity: 
    <input type="number" name="product_quentity" ><br></div> 
    <div class="form-group">
    
    Product Price: 
    <input type="number" name="product_price" ><br></div> 
    <div class="form-group">
    Product Total Price:  
    <input type="number" name="product_tprice"><br></div> 

    <div class="form-group">
    Give some more information for product : 
    <input type="text" name="product_info"></div> 

    <div class="form-group">
    <input type="submit" name="update" ></div>
</center>
</form> 
</body>
</html>   

