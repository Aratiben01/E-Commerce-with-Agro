<?php include 'head.php'; 
include 'db_collect.php';

 ?> 
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sell</title> 
   
 </head>
 <body> <center>
    <div class="container"> 
        <section class="display_product"> 
            
</thead>

<tbody>  
    <?php  
    $display_product=mysqli_query($conn,"Select * from `product`"); 
    if(mysqli_num_rows($display_product)>0){
        echo " <table border='1'> 
                 <thead> 
                    <td>ID</td>
                    <td>Name</td>
                    <td>Image </td>
                    <td>Quentity</td>
                    <td>price</td>
                   
                    <td>Information</td> 
                    <td> React</td>";
        while($row=mysqli_fetch_assoc($display_product)){
           // $product_name=$row['name']; 
            echo "<tr> "; 
            echo "<td>". htmlspecialchars($row['id']) ."</td>"; 
            echo "<td>". htmlspecialchars($row['name'])."</td>";
            echo "<td><img src='img/" . htmlspecialchars( $row["image"]) . "' alt=' ' class='img'> </td>";  
           
            echo "<td> ". htmlspecialchars($row['quentity'])."</td>"; 
            echo "<td>". htmlspecialchars($row['price'])."</td>"; 
                       echo "<td>". htmlspecialchars($row['info'])."</td> ";  
            echo "";
           echo "<td>
    <form action='delete.php' method='post' style='display:inline;'>
        <input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>
        <button type='submit' name='delete'>Delete</button>
    </form>";

// Update Form
echo "<form action='update.php' method='post' style='display:inline;'>
        <input type='hidden' name='id' value='" . htmlspecialchars($row['name']). htmlspecialchars($row['id']) 
        . htmlspecialchars( $row["image"]). htmlspecialchars($row['quentity']). htmlspecialchars($row['price'])
        . htmlspecialchars($row['tprice']). htmlspecialchars($row['info']). "'>
        <button type='submit' name='update_item'>Update</button>
    </form>"; 
     //booked form 
     echo "<form action='buy.php' method='post' style='display:inline;'>
        <input type='hidden' name='id' value='" . htmlspecialchars($row['quentity']). "'>
        <button type='submit' name='book'>book</button>
    </form>
    </td></tr>";
              }            
          ?> </table> <?php 
        
        echo "yes"; 
        }
    else{
        echo " <center><div class='empty_text'> No product  </div></center>";
    }?>
  
    
</tbody>
</table>
</div>
</center>
 </body>
 </html>