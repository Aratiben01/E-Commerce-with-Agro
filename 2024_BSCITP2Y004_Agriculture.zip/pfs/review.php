<?php include 'head.php'; 
include 'db_collect.php';


 ?> 
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sell</title>  
    <style>  
    .add{
        margin-top: 100px;
        margin-right: 1000px; 
        

    }
    </style>
   
 </head>
 <body> <center>
    <div class="container"> 
        <section class="display_product"> 
            
</thead>

<tbody>  
    <?php     

    $display_rvu=mysqli_query($conn,"Select * from `feedback`"); 
   
    
    if(mysqli_num_rows($display_rvu)>0){
        echo " <table border='1'> 
                 <thead> <a href='add.php' class='add'> Add </a> <br> <br><br>
                    <td>ID</td>
                    <td>Product Id</td>
                    <td>User Name </td>
                    <td>Review</td>";
        while($row=mysqli_fetch_assoc($display_rvu))
        {
           // $product_name=$row['name']; 
           
           ?>
           
        <tr> 
            <td> <?= $row['id'] ?> </td>
            <td><?= $row['proid'] ?></td>
            <td> <?= $row['user']?> </td> 
            <td><?= $row['review']?> </td> 
            
            </table> <?php        
        }}
    else{
        echo "<a href='add.php' class='add'> Add </a>";
       echo " <center>No Reviews and Feedbacks </center>";
    }?>
  
    
</tbody>
</table>
</div>
</center>
 </body>
 </html>