<?php 

error_reporting(0);
$conn=mysqli_connect('localhost','root','','db_collect');
if($conn){
  //  echo "done";

}
else{
    echo "not done";
}
?>