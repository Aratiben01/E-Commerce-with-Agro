<?php 
include "head.php";
include "db_collect.php"; 

 $qry="select * from book"; 
 $rec=mysqli_query($conn,$qry); 
 if(mysqli_num_rows($rec)>0){
 
 while($row=mysqli_fetch_assoc($rec))
{ 
   
     
    $proqry="select * from product where id=".$row['proid'];
    $prorec=mysqli_query($conn,$proqry); 
    $prorow=mysqli_fetch_assoc($prorec);
    echo "<center> <table border='1'> 
    <tr> 
    <td>Booked ID</td> 
    <td> ID </td>
    <td> User Name </td>
    <td> Name </td>
    <td> Image </td>
    <td> Quentity </td>
    <td> price </td>
    <td> Information </td> 
    <td> React </td></tr>";
    
    ?>
   <tr>
   <td><?= $row['id'] ?></td>
   <td><?= $row['proid'] ?></td>  
    <td><?= $row['usernm'] ?></td>  
    <td><?= $prorow['name'] ?></td>  
    <td><img src='img/<?=$prorow["image"]?>' alt=' ' class='img'> </td>  
           
            <td> <?= $row['qty']?> </td> 
            <td><?= $prorow['price']?> </td>
            
           <td> <?=$prorow['info']?></td>   <?php
           $val=$row['id'];

         echo "<td><a href=bcl.php?id=$val>   Delete    </a> <br><br>"; 
         echo "<a href=pdone.php?id=$val>    done  </a></td>"; ?>
        
    
</tr> </table></center>
   <?php
}
}
?>