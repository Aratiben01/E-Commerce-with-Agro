
<?php  

include 'db_collect.php';  
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['done'])){ 
    $product_code=$_POST['icode'];  
    $product_quentity=$_POST['product_quentity'];
    $product_price=$_POST['product_price'];
    $product_tprice=$_POST['product_tprice'];
    $product_info=$_POST['product_info'];  
   

    try{/*

    echo "<br>updated<br>";*/  

        $sql = "UPDATE product SET quentity='$product_quentity', price='$product_price',
         tprice='$product_tprice', info='$product_info' WHERE icode ='$product_code'"; 
        // echo $sql;

// Pass the query variable to mysqli_query()
            $update_query = mysqli_query($conn, $sql);

// Optional: check for errors
            if ($update_query) {
                    echo "Record updated successfully";
                } else {
                    echo "Error updating record: " . mysqli_error($conn);
                }
} 
catch(Exception $e){
    echo "Error  !!!!";
}
if($update_query){
    echo "<br>product update";  
    //header('location:sell.php'); 
    //exit();
}
    else{
        $display_message= "some thing error in uploding";
    }
 }   


?> 

<html>
<head></head>  
<style>
  form
          {
              display: flex;
              flex-direction: column;
              height: 300px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 250px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
  </style> 
<body class="body"> 
    <form action="sell.php" method="post" class="form">  
        <center> 
      <h1> About you <br><b>
        Name:
        <input type="text" name="nm" plasholder="Your name"> <br> 
        Country:
        <input type="text" name="country" value=""><br> 
        State: 
        <input type="text" name="state" value=""><br>  
        City: 
        <input type="text" name="dic" value=""><br>  
        Address: 
        <input type="address" name="add" value="" row=15 colen><br>  
        
        <input type="radio" name="prof" value="FARMER"> 
        <label for="FARMER">FARMER</label>
        <input type="radio" name="prof" value="SELLER"> 
        <label for="SELLER">SELLER</label><br> 

        <input type="submit" name="Done"> 
</h1></b>
</center>    
</form>
</body>
</head>
</html> 
