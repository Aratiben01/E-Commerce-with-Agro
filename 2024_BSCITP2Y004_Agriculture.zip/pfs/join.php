<?php

include 'db_collect.php'; 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if(isset($_POST['next'])){
    $usernm=$_POST['unm'];  
    $psw=$_POST['psw'];   
    $nm=$_POST['nm']; 
    
    //echo $product_name;  
    try{
        echo "<br> Join Succesfully ";
        $insert_query=mysqli_query($conn,"insert into `si` (urnm,psw,nm) values
    ('$usernm','$psw','$nm')");   

     
       echo $insert_query;
        
    echo "<br> Click Next  <br> "; 
   
    
} 
catch(Exception $e){
    echo "Error  !!!!";
}
    if($insert_query){ 
        move_uploaded_file($product_img_temp_name,$product_img_folder);
        $display_message= "product uploded succesfully";
    }
    else{
        $display_message= "some thing error in uploding";
    }
 }   
?>
<html>
    <style>
        body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
</style>
    <body>  <center> 
    <form action='currentsell.php' method='post'>
      <a href=currentsell.php?id=$usernm> 
      <input type='submit' value='next page'></a>
      
        </form></center>
</body> 
</html>