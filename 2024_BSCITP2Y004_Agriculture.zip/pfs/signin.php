

<?php  
include 'db_collect.php'; 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

/*if(isset($_POST['next'])){
    $usernm=$_POST['unm'];  
    $psw=$_POST['psw'];  
    
    //echo $product_name;  
    try{
        echo "<br>first";
        $insert_query=mysqli_query($conn,"insert into `si` (unm,psw) values
    ('$usernm','$psw')");   

      echo "<form action='currentsell.php' method='post'>
      <a href=currentsell.php?id=$usernm> 
      <input type='submit' value='next page'></a> 
      </form";
       echo $insert_query;
        
    echo "<br>tgnmkh <br> "; 
   
    
} 
catch(Exception $e){
    echo "Error  !!!!";
}
    if($insert_query){ 
        move_uploaded_file($product_img_temp_name,$product_img_folder);
        $display_message= "product uploded succesfully";
    }
    else{
        $display_message= "some thing error in uploding";
    }
 }  */ 

?> 
<html>
    <head> Signin
    </head>
    <body>   
    <style>
    .form-container {
        margin: 20px; /* Adds space around the form */
    }

    .form-group {
        margin-bottom: 15px; /* Adds space between form groups */
    }

    input, textarea, select {
        padding: 10px; /* Adds space inside form controls */
        margin-right: 10px; /* Adds space to the right of form controls */
    } 
    form
          {
              display: flex;
              flex-direction: column;
              height: 330px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 250px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
</style>

<div class="form-container">
        <form action="join.php" class="form" method="post">
        <h1>hello </h1> 
      
        <div class="form-group">
        Username : 
        <input type='text' name='unm'> <br></div> 
        <div class="form-group">
        Password : 
        <input type='password' name='psw'> <br>  </div> 
        <div class="form-group">  
        Name:
        <input type="text" name="nm" plasholder="Your name"> <br> 
        </div>
       
         <!--
        <div class="form-group">   
        code: 
        <input type='password' name='code'><br></div> --> 
        
        <div class='form-group'>
            You are farmer or Agro Seller ... <br>
        <input type='submit' name='next'></div>   
         <div class='form-group'>
            You are farmer or Agro Seller ... <br>
        
      
    
    </form>
    </body>
</html>