<?php
include 'db_collect.php'; 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if(isset($_POST['gop'])){
 
  $log_usernm=$_POST['un'];  
   echo $log_usernm;
    $log_pw=$_POST['pw'];   
       $loginy=mysqli_query($conn,"Select * from `si`"); 
        if(mysqli_num_rows($loginy)>0){
            
            while($row=mysqli_fetch_assoc($loginy))
            {
                 if($log_usernm==$row['urnm']&&$log_pw==$row['psw']){
                  
                  echo "<html>
    <style>
        body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
</style>
    <body>  <center>  
    <form action='login.php' method='post'>
      <a href=login.php?id=$usernm> 
      <input type='submit' value='back'></a>
      
        </form>

    <form action='currentsell.php' method='post'>
      <a href=currentsell.php?id=$usernm> 
      <input type='submit' value='next page'></a>
      
        </form></center>
</body> 
</html>";

        }           
     }            
        }       
        else{ 
                    echo "<html>
          <style>
              body
                {
                  background-image: url('img/1598228.JPG');
                    background-repeat: no-repeat; 
                    background-attachment: fixed;
                    background-size: 100% 100%;
                }
      </style>
          <body>  <center>  
          <form action='login.php' method='post'>
            <a href=login.php?id=$usernm> 
            <input type='submit' value='back'></a>
            
              </form></center>
</body> 
</html>";
echo "<br>Check Your Username & Password <br>"; 
echo "<br> Go Back to login page  <br>";

            
        }
}
?>

