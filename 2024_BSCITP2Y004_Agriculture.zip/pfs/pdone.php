<?php 
include "head.php"; 
include "db_collect.php"; 
 echo "hello<br>"; 
 $id=$_GET['val'];  

 echo $id; 

if(isset($_GET['id']))
{
    
    $delete_id=$_GET['id'];  
    echo $delete_id."<br>"; 

    $delete_query=mysqli_query($conn,"Delete from `book` where id=$delete_id") or die("Query failed"); 
    if($delete_query){
        echo "product delete";  
        header('location:book.php'); 
        //exit();
    }
    else{
        echo "product not deleted "; 
        
    }
} 
?>