<?php  
include 'head.php';  
include 'db_collect.php';?> 


<html>

<style>
    .form-container {
        margin: 20px; /* Adds space around the form */
    }

    .form-group {
        margin-bottom: 15px; /* Adds space between form groups */
    }

    input, textarea, select {
        padding: 10px; /* Adds space inside form controls */
        margin-right: 10px; /* Adds space to the right of form controls */
    }
  .form
          {
              display: flex;
              flex-direction: column;
              height: 230px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 70px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          .body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
  </style> 
<body class="body"> 

<div class="form-container"> 
        <!-- message --> 
         <?php  
         $id=$_GET['id'];
         $bid="select * from product where id=$id";
         $rec=mysqli_query($conn,$bid);
         $row=mysqli_fetch_array($rec);

         if(isset($display_message)){
            echo "<div class='display_message'> <span>$display_message </span> 
            <i class='fas fa-times' onclick='this.parentElement.style.display=`none`';></i>
             </div";
         }
         ?> 
         
<form class="form" action="" method="post" enctype="multipart/form-data"> 
    <center> 
        <div class="form-group"> <br>
    ID : <input type="text" name="product_id" value=<?=$id?>><br></div>
        <div class="form-group">
        Product Quentity: 
    <input type="number" name="product_quentity" ><br></div> 
    <div class="form-group">
        user Name: 
    <input type="text" name="buser" ><br></div>   
    <div class="form-group">
    <input type="submit" name="book" ></div>
</center>
</form> 
</body>
</html>   










<?php 

        echo "<center>";
            //error_reporting(E_ALL);
            //ini_set('display_errors', 1);

if(isset($_POST['book'])){  
    $qun=$row[1]-$_POST['product_quentity'];
    echo $qun;
    if($qun>0)
    {
    $sql = "UPDATE product SET quentity='$qun' WHERE id ='$id'"; 
    mysqli_query($conn,$sql);

    $qry="insert into book (proid,qty,usernm) values($id,$_POST[product_quentity],'$_POST[buser]')";
    echo $qry;
    mysqli_query($conn,$qry);
    }
    else{
        echo "<br>Product is not available<br>";
    }





  $display_product=mysqli_query($conn,"Select * from `product`"); 
   if(mysqli_num_rows($display_product)>0){ 
    $product_id=$_POST['product_id'];  
    

    

   $product_quentity=$_POST['product_quentity'];    
   echo $product_quentity;

 
    while($row=mysqli_fetch_assoc($display_product)){
       // $product_name=$row['name'];  
       if($row['id']==$product_id){
      
       ?><table border="1">
        <tr> 
            <td> <?= $row['id'] ?> </td>
            <td><?= $row['name'] ?></td>
            <td><img src='img/<?=$row["image"]?>' alt=' ' class='img'> </td>  
           
            <td> <?= $_POST['product_quentity']?> </td> 
            <td><?= $row['price']?> </td>
            <td><?= $row['tprice']?> </td> 
           <td> <?=$row['info']?></td>   
        <td></table>
    
<?php
    }
    } 
}
     }   

 echo "<center>"; 

?> 

  