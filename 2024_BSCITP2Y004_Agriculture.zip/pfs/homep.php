
<?php  
include 'head.php'; 
include 'db_collect.php'; 

echo "Home page "; 
?> 
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy and Sell Home Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<main>
        <section id="hero">
            <div class="container">
                <h2>Welcome to Our Marketplace</h2>
                <p>Your one-stop shop for buying and selling products.</p>
                <form id="search-form">
                    <input type="text" placeholder="Search for products..." name="search" required>
                    <button type="submit">Search</button>
                </form>
            </div>
        </section>
        <section id="products">
            <div class="container">
                <h2>Featured Products</h2>
                <div class="product-list">
                    <!-- Product 1 -->
                    <div class="product-item">
                        <img src="example1.jpg" alt="Product 1">
                        <h3>Product 1</h3>
                        <p>Price: $99.99</p>
                        <a href="product-detail.html?id=1">View Details</a>
                    </div>
                    <!-- Product 2 -->
                    <div class="product-item">
                        <img src="example2.jpg" alt="Product 2">
                        <h3>Product 2</h3>
                        <p>Price: $199.99</p>
                        <a href="product-detail.html?id=2">View Details</a>
                    </div>
                    <!-- Add more products as needed -->
                </div>
            </div>
        </section>
</body> 
</html> 
