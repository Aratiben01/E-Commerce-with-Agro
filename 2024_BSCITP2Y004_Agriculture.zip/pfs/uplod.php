
<?php  


include 'head.php';  
include 'db_collect.php'; 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if(isset($_POST['uplod'])){
    $product_code=$_POST['product_code'];  
    $product_name=$_POST['product_name'];  
    $product_quentity=$_POST['product_quentity'];
    $product_price=$_POST['product_price'];
    $product_tprice=$_POST['product_tprice'];
    $product_img=$_FILES['product_img']['name'];
    $product_img_temp_name=$_FILES['product_img']['temp_name']; 
    $product_img_folder='img/'.$product_img;

    $product_info=$_POST['product_info'];
    //echo $product_name;  
    try{
        echo "<br>first";
        $insert_query=mysqli_query($conn,"insert into `product` (icode,name,quentity,price,tprice,image,info) values
    ('$product_code','$product_name','$product_quentity','$product_price','$product_tprice','$product_img','$product_info')");
   echo $insert_query;
        
    echo "<br>tgnmkh <br> "; 
   
    
} 
catch(Exception $e){
    echo "Error  !!!!";
}
    if($insert_query){ 
        move_uploaded_file($product_img_temp_name,$product_img_folder);
        $display_message= "product uploded succesfully";
    }
    else{
        $display_message= "some thing error in uploding";
    }
 }   

?> 
<html>

<style>
    .form-container {
        margin: 20px; /* Adds space around the form */
    }

    .form-group {
        margin-bottom: 15px; /* Adds space between form groups */
    }

    input, textarea, select {
        padding: 10px; /* Adds space inside form controls */
        margin-right: 10px; /* Adds space to the right of form controls */
    }
  .form
          {
              display: flex;
              flex-direction: column;
              height: 490px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 100px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          .body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
  </style> 
<body class="body"> 

<div class="form-container"> 
        <!-- message --> 
         <?php  
         if(isset($display_message)){
            echo "<div class='display_message'> <span>$display_message </span> 
            <i class='fas fa-times' onclick='this.parentElement.style.display=`none`';></i>
             </div";
         }
         ?> 
         
<form class="form" action="" method="post" enctype="multipart/form-data"> 
    <center> 
   
    <div class="form-group"> <br>
    code : <input type:"text" name="product_code"><br></div>
        <div class="form-group">
    Product Name: 
    <input type="text" name="product_name"><br> </div> 
    <div class="form-group">
    
    product Quentity: 
    <input type="number" name="product_quentity" ><br></div> 
    <div class="form-group">
    
    Product Price: 
    <input type="number" name="product_price" ><br></div> 
    <div class="form-group">
    
    Product Total Price:  
    <input type="number" name="product_tprice"><br></div> 
    <div class="form-group">
    
    Choose an image to upload:
    <input type="file" name="product_img" accept="image/*" required>
    <br><br></div> 
    <div class="form-group">
    
    Give some more information for product : 
    <input type="text" name="product_info"></div>  
    
    <div class="form-group">
    <input type="submit" name="uplod" ></div>
</center>
</form> 
</body>
</html> 