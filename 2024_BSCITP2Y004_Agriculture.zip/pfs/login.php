<html>
    <head>login 
    </head>
    <style>
    .form-container {
        margin: 20px; /* Adds space around the form */
    }

    .form-group {
        margin-bottom: 15px; /* Adds space between form groups */
    }

    input, textarea, select {
        padding: 10px; /* Adds space inside form controls */
        margin-right: 10px; /* Adds space to the right of form controls */
    }
    form
          {
              display: flex;
              flex-direction: column;
              height: 300px;
              width: 500px; 
              border: 1px solid rgb(64, 64, 174); 
              align-items:center ;
              margin: auto;
              margin-top: 250px;
              background-color: rgb(0, 0, 0,0.5); 
              box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
              border-radius: 20px;
          }
          body
          {
            background-image: url('img/1598228.JPG');
              background-repeat: no-repeat; 
              background-attachment: fixed;
              background-size: 100% 100%;
          }
    </style>
    <body class="body">   
    <div class="form-container">
<center>
        <form action="go.php" class="form" method="POST">
        <h1>hello </h1> 

        <div class="form-group">
        Username : 
        <input type='text' name='un'> <br></div> 
        <div class="form-group">
        Password : 
        <input type='password' name='pw'> <br></div> 
         
        <div class="form-group">
        You are farmer or Agro Seller ... <br>
        <input type="submit" name="gop"></div> 
        </form></center>
    </body>
</html>