

<?php include 'head.php'; 
include 'db_collect.php';


 
 if(isset($_POST['review'])){
     $prodid=$_POST['prodid'];  
     $name=$_POST['name'];  
     $rvu=$_POST['rvu'];
     
 
     //echo $product_name;  
     try{
         echo "<br>first";
         $insert_query=mysqli_query($conn,"insert into `feedback` (proid,user,review) values('$prodid','$name','$rvu')");
    echo $insert_query;
         
     
 } 
 catch(Exception $e){
     echo "Error  !!!!";
 }
     if($insert_query){ 
         //move_uploaded_file($product_img_temp_name,$product_img_folder);
         $display_message= "product uploded succesfully";
     }
     else{
         $display_message= "some thing error in uploding";
     }
  }   
 
 ?> 
 <html>
 
 <style>
     .form-container {
         margin: 20px; /* Adds space around the form */
     }
 
     .form-group {
         margin-bottom: 15px; /* Adds space between form groups */
     }
 
     input, textarea, select {
         padding: 10px; /* Adds space inside form controls */
         margin-right: 10px; /* Adds space to the right of form controls */
     }
   .form
           {
               display: flex;
               flex-direction: column;
               height: 210px;
               width: 500px; 
               border: 1px solid rgb(64, 64, 174); 
               align-items:center ;
               margin: auto;
               margin-top: 100px;
               background-color: rgb(0, 0, 0,0.5); 
               box-shadow: inset -5px -5px rgba(0,0,0,0.8); 
               border-radius: 20px;
           }
           .body
           {
             background-image: url('img/1598228.JPG');
               background-repeat: no-repeat; 
               background-attachment: fixed;
               background-size: 100% 100%;
           }
   </style> 
 <body class="body"> 
 
 <div class="form-container"> 
         <!-- message --> 
          <?php  
          if(isset($display_message)){
             echo "<div class='display_message'> <span>$display_message </span> 
             <i class='fas fa-times' onclick='this.parentElement.style.display=`none`';></i>
              </div";
          }
          ?> 
          
 <form class="form" action="" method="post" enctype="multipart/form-data"> 
     <center> 
    
     
         <div class="form-group">
     Product id: 
     <input type="number" name="prodid"><br> </div> 
     <div class="form-group">
     
     User Name: 
     <input type="text" name="name" ><br></div> 
     <div class="form-group">
     
     Reviews for product : 
     <input type="text" name="rvu"></div>  
     
     <div class="form-group">
     <input type="submit" name="review" ></div>
 </center>
 </form> 
 </body>
 </html> 