<?php include 'head.php'; 
include 'db_collect.php';


 ?> 
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sell</title> 
   
 </head>
 <body> <center>
    <div class="container"> 
        <section class="display_product"> 
            
</thead>

<tbody>  
    <?php   
  

    $display_product=mysqli_query($conn,"Select * from `product`"); 
    if(mysqli_num_rows($display_product)>0){
        echo " <table border='1'> 
                 <thead> 
                    <td>ID</td>
                    <td>Name</td>
                    <td>Image </td>
                    <td>Quentity</td>
                    <td>price</td>
                    <td>Total Price</td>
                    <td>Information</td> 
                    <td> React</td>";
        while($row=mysqli_fetch_assoc($display_product))
        {
           // $product_name=$row['name']; 
           ?>
        <tr> 
            <td> <?= $row['id'] ?> </td>
            <td><?= $row['name'] ?></td>
            <td><img src='img/<?=$row["image"]?>' alt=' ' class='img'> </td>  
           
            <td> <?= $row['quentity']?> </td> 
            <td><?= $row['price']?> </td>
            <td><?= $row['tprice']?> </td> 
           <td> <?=$row['info']?></td>   
        <td>
    
<?php
$val=$row['id'];
// Update Form  
echo "<a href=delete.php?id=$val> Delete</a>";  
$val2=$row['icode'];
echo "<a href=update.php?id=$val> Update</a>"; 
echo "<a href=buy.php?id=$val> Book </a>";
  
              }            
          ?> </table> <?php 
        
        echo "yes"; 
        }
    else{
        echo " <center><div class='empty_text'> No product  </div></center>";
    }?>
  
    
</tbody>
</table>
</div>
</center>
 </body>
 </html>