
<?php  
include 'head.php';  
include 'db_collect.php';  
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_GET['id'])){ 
    $product_code=$_POST['icode'];  
    $product_quentity=$_POST['product_quentity'];
    $product_price=$_POST['product_price'];
    $product_tprice=$_POST['product_tprice'];
    $product_info=$_POST['product_info'];  
   

    try{/*

    echo "<br>updated<br>";*/  

        $sql = "UPDATE product SET quentity='$product_quentity', price='$product_price',
         tprice='$product_tprice', info='$product_info' WHERE icode ='$product_code'"; 
        // echo $sql;

// Pass the query variable to mysqli_query()
            $update_query = mysqli_query($conn, $sql);

// Optional: check for errors
            if ($update_query) {
                    echo "Record updated successfully";
                } else {
                    echo "Error updating record: " . mysqli_error($conn);
                }
} 
catch(Exception $e){
    echo "Error  !!!!";
}
if($update_query){
    echo "<br>product update";  
    //header('location:sell.php'); 
    //exit();
}
    else{
        $display_message= "some thing error in uploding";
    }
 }   


?> 