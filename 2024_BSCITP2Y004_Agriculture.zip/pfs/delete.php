<?php 
include "head.php"; 
include "db_collect.php"; 
 echo "hello<br>"; 
 $id=$_GET['val'];  

 echo $id; 

if(isset($_GET['id']))
{
    
    $delete_id=$_GET['id'];  
    echo $delete_id."<br>"; 

    $delete_query=mysqli_query($conn,"Delete from `product` where id=$delete_id") or die("Query failed");  
    $delt_qry=mysqli_query($conn,"Delete from `book` where id=$delete_id") or die("Query failed");

    if($delete_query){
        echo "product delete";  
        
        if($delt_qry){
            echo "booked record delete also !!!";
        } 
        else{
            echo "Product in Book data ...";
        }
        header('location:currentsell.php');  
        //exit();
    }
    else{
        echo "product not deleted "; 
        
    }
} 
?>