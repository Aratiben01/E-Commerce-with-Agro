<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce Header</title>
    <link rel="stylesheet" href="styles.css">
    </head>  
    <style>

        
        </style>
    <body style="background-image: url('img/bgd.JPG'); background-size: cover;
     background-repeat: no-repeat; background-position: center;">


        <header>
        <div class="header-container">
        <h1 class="logo">
            <a href="index.php"><img src="img/logo.jpg" class="logo"> 
                
            </a>E-commerce with Agro 
        </h1>
        <!--
            <h1 class="logo"><a href="index.php"> E-commerce with Agro</a></h1>
-->
            <nav class="nav-menu">
                <ul>
                    <li><a href="uplod.php"> Uplode </a> </li>
                   <!-- <li><a href="homep.php"> Home </a> </li>-->
                    <li><a href="currentsell.php"> Current sell </a></li>
                    <li><a href="sell.php"> Sell </a></li> 
                    <li><a href="book.php"> Booked </a></li> 
                    <li><a href="review.php"> Review </a></li> 
                   
</ul>
</nav> 
</div>
</header>
    </b>
    </body>  
</html>